package model.dell.com;


import command.dell.com.*;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Register extends PageBase {
    public Register(String filename, WebDriver driver ) {
        super(filename);
        this.driver=driver;
    }




    public void fillForm(String first, String last, String mobile, String email, String password, String address, String city, String zip){
        WaitCommandControl waitCommandControl= new WaitCommandControl();
        CommandControl commadControl = new CommandControl();

        ConcreteWaitCommand concreteWaitCommand = new ConcreteWaitCommand(driver);
        waitCommandControl.setCommand(concreteWaitCommand);
        waitCommandControl.waitUntilVisible(eles.get("signIn"));




        ClickCommand clickCommand = new ClickCommand(driver);
        SendKeysCommand SendKeysCommand = new SendKeysCommand(driver);

        commadControl.setCommand(clickCommand);
        commadControl.performClick(eles.get("signIn"));
        waitCommandControl.waitUntilVisible(eles.get("email_create"));

        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("email_create"),email+ Keys.TAB);
        waitCommandControl.waitUntilVisible(eles.get("createAccount"));
        commadControl.setCommand(clickCommand);
        commadControl.performClickOnSpecificIndex(eles.get("createAccount"),0);
        waitCommandControl.waitUntilLoaded("http://automationpractice.com/index.php?controller=authentication&back=my-account#account-creation");
        waitCommandControl.waitUntilVisible(eles.get("heading"));
        commadControl.performClick(eles.get("titleMr"));

        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("firstName"),first);
        commadControl.performSendKeys(eles.get("lastName"),last);
        commadControl.setCommand(SendKeysCommand);
        //commadControl.performSendKeys(eles.get("mobile"),mobile);

        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("password"),password);
        waitCommandControl.waitUntilVisible(eles.get("address"));
        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("address"),address);

        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("city"),city);
        commadControl.setCommand(clickCommand);
        commadControl.performSendKeys(eles.get("state"), "Alabama");
        commadControl.setCommand(SendKeysCommand);
        commadControl.performSendKeys(eles.get("postcode"), zip);
        commadControl.performSendKeys(eles.get("mobile"),mobile);
        commadControl.setCommand(clickCommand);
        commadControl.performClick(eles.get("register"));

        waitCommandControl.waitUntilLoaded("http://automationpractice.com/index.php?controller=my-account");
        String namer=first+" "+last;
        commadControl.setCommand(SendKeysCommand);
        waitCommandControl.waitUntilVisible(eles.get("fullName"));
        Assert.assertEquals(namer,commadControl.getString(eles.get("fullName"),0,0));
    }
}
