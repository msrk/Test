package test.dell.com;

import model.dell.com.Purchase;
import model.dell.com.Register;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Iterator;

public class LogINTest extends BaseTest{

    @BeforeClass(alwaysRun = true)
    public void loadData() {
        testData = getTestDataAsObjectArray("File4.xls");
    }

    @DataProvider(name = "test1", parallel = false)
    public Iterator<Object[]> loadTestData() {

        return this.testData.iterator();
    }



    @Test(dataProvider = "test1")
    public void registerAUser(HashMap<String, String> columns) {
        try {
            logger = extent.createTest("register and purchase");
            Register register = new Register("Register.json", driver);
            register.fillForm(columns.get("firstname"),columns.get("lastname"), columns.get("mobile"),"itooiitt"+columns.get("email"), columns.get("password"),columns.get("address"),columns.get("city"),columns.get("zip"));
            Purchase purchase = new Purchase("Purchase.json", driver);
            purchase.purchase();
            driver.close();

        } catch (Exception e) {
            logger.createNode(e.getStackTrace().toString());
            logger.createNode("Test has failed");
            Assert.assertTrue(false);

        }

    }
}
